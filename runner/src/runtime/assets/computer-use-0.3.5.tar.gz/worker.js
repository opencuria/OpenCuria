import { createRequire as __createRequire } from 'node:module'; const require = __createRequire(import.meta.url);

// src/worker.ts
import inspector from "node:inspector";
import { AsyncLocalStorage } from "node:async_hooks";
import { format, inspect } from "node:util";
import { readFile, realpath, stat } from "node:fs/promises";
import path from "node:path";

// src/contract.json
var contract_default = {
  version: "0.3.0",
  surfaces: [
    "computer"
  ],
  tools: [
    {
      name: "js",
      description: 'Control native apps or browsers on the user\u2019s computer by reading or operating UI. Prefer purpose-built skills, connectors, APIs, or CLIs when available.\n\nOn the first invocation of `cua_repl`, or after resetting it, execute exactly one of the API calls shown below, optionally assigning its result to a variable. Do not add other API calls, waits, or snapshots to that invocation.\nThe tool result will include documentation and, when creating or selecting a tab or selecting an app, its initial UI state. Selecting a browser does not open a tab. Read that result before continuing.\nUse only APIs described in the tool instructions or returned documentation.\n\nWhen you need an inventory of available apps, browsers, and tabs, get a snapshot of all enabled surfaces. Otherwise, use the relevant entry point below:\n\n```javascript\nawait cua.getState();\n```\n\nBrowser APIs are disabled.\n\nIf the user specifies an app to use, get the app by name, bundle ID, or path:\n\n```javascript\nlet app = await cua.getApp("Example App");\n```\n\nTo add other content to the tool result, use `nodeRepl.write(value)` for text or other values and `await nodeRepl.emitImage(image)` for images. The APIs listed above already display their documentation or UI state; do not wrap their results in `write` or `emitImage`.\n\nIf your context begins with a summary of an existing computer use task, call `await cua.rewriteDocumentation()` before continuing the computer use task to ensure you have a complete view of the necessary documentation.',
      inputSchema: {
        type: "object",
        properties: {
          code: {
            description: "JavaScript to execute using the initialized cua_repl runtime.",
            type: "string"
          },
          timeout_ms: {
            description: "Optional execution timeout in milliseconds. Defaults to 30000 (30 seconds) when omitted.",
            minimum: 1,
            type: "integer"
          },
          title: {
            description: "Short user-facing description of what the code does.",
            maxLength: 80,
            minLength: 1,
            type: "string"
          }
        },
        required: [
          "code"
        ],
        additionalProperties: false
      }
    },
    {
      name: "js_reset",
      description: "Reset the persistent cua_repl JavaScript session. All JavaScript bindings are discarded. The next cua_repl.js call initializes a fresh runtime for the enabled surfaces. This does not close browser tabs or native apps, or erase their state.",
      inputSchema: {
        type: "object",
        properties: {},
        additionalProperties: false
      },
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        openWorldHint: false
      }
    },
    {
      name: "turn_ended",
      description: "Notify trusted libraries that a Codex turn ended. Repeated notifications for the same session and turn are ignored.",
      inputSchema: {
        type: "object",
        properties: {
          hook_event_name: {
            minLength: 1,
            type: "string"
          },
          session_id: {
            minLength: 1,
            type: "string"
          },
          turn_id: {
            minLength: 1,
            type: "string"
          }
        },
        required: [
          "hook_event_name",
          "session_id",
          "turn_id"
        ],
        additionalProperties: false
      },
      annotations: {
        idempotentHint: true
      },
      _meta: {
        ui: {
          visibility: []
        }
      }
    }
  ],
  documentation: '## Computer Use (Linux desktop)\n\nOperate native apps and browsers on the workspace desktop with `cua_repl` (JavaScript with top-level await). Prefer purpose-built tools, APIs or CLIs when they can do the job, and use `cua_repl` rather than xdotool or other input tools for UI work. Variables, functions and app bindings persist across calls and turns of this chat.\n\n### Start\n```js\nconst app = await cua.getApp("Chrome");  // app name or window title text; launches an installed app if no window is open\n// also: cua.getApp({ title: /Invoice/ }), cua.getApp({ windowId }) from cua.listWindows(), cua.getApp({ app, title }); these bind open windows only\n```\n`getApp` prints the window\'s accessibility tree once (`{ emit: false }` skips it). Dialogs are separate windows: `await cua.waitForWindow({ title: /Open/ })`, `cua.listWindows()`, `cua.listApps()`.\n\n### Targets\nEvery action takes a target:\n- A query (recommended): `{ role: "button", name: "Save" }`, `{ name: "Email" }`, `{ role: "radio", context: "Violence \u203A None" }`, `"Upload"` (text of a tree line) or `/regex/`. Keys: `role`, `name`, `value`, `text` (name, value, description or context), `context`, `description`, `states` (`["checked"]`, `["!disabled"]`), `within` (a target whose subtree is searched), `index` (0-based match). Roles accept common names: button, textbox, checkbox, radio, combobox, option, link, menuitem, tab, dialog, table, cell, row, heading, image, slider. Strings match case-insensitively as substrings; an exact name wins among several matches, and actions prefer operable controls over their labels. A query is resolved when the action runs and waits up to 5 s (`timeoutMs`) for the element.\n- An element ID from the tree, e.g. `42`. IDs stay the same while the element exists.\n- `[x, y]` in the latest screenshot of this app (window pixels before any screenshot).\n\n### Observe\n```js\nawait app.getAXState();                    // after the first full tree only changes are printed (+ added, ~ changed, - removed)\nawait app.getAXState({ disableDiffing: true, root: { role: "dialog" } }); // everything, or one subtree\nawait app.find({ role: "textbox" });       // prints and returns only matches: [{ id, role, name, value, states, context, line }]\nawait app.waitFor("Saved", { timeoutMs: 10000 });         // waits until something matches; returns it\nawait app.waitFor({ text: "Processing" }, { gone: true }); // waits until it disappeared\nawait app.getScreenshot({ maxDimension: 1000, region: { role: "dialog" } }); // smaller images cost fewer tokens\nawait app.getAXStateAndScreenshot();\n```\nTree lines read `id role (states) name, Value: \u2026, Description: \u2026, Context: \u2026, Secondary Actions: \u2026`. `Context` describes an unlabeled control by its row/column header or neighboring label, e.g. `radio button (unchecked) Context: Cartoon violence \u203A None`. Hidden widgets are omitted. After input, observations wait until the app stops changing; use `waitFor` for slower loading. Return values are always complete: pass `{ emit: false }` and filter in code instead of printing large trees.\n\n### Act\n```js\nawait app.setValue(target, "1.0.0");  // replaces a field\'s text; also picks a combo box/list option by text,\nawait app.setValue(target, true);     // sets a checkbox, radio button or switch, and a slider/spin value (number);\n                                      // verifies the result and returns { value } or { checked }\nawait app.click(target, { clickCount: 2, mouseButton: "right", key: "shift", durationMs: 500 });\nawait app.hover(target);              // moves the pointer over it (menus and tooltips that open on hover)\nawait app.typeText("text", target);   // inserts at the caret of target (or the focused element); Unicode and multi-line\nawait app.typeCharacters("20");       // real key presses into the focused element, for fields that reject pasting\nawait app.pressKey("ctrl+a", { repeat: 1 });  // xdotool key names: "Return", "Tab", "Escape", "ctrl+shift+t"\nawait app.focus(target); await app.selectText(target, "word", { prefix, suffix, selectionType: "text" });\nawait app.scroll(target, "down", { pixels: 600 }); await app.scrollIntoView(target);\nawait app.drag(fromTarget, toTarget);\nawait app.performSecondaryAction(target, "expand"); // only actions listed in the tree\nawait app.getBounds(target);          // { x, y, width, height } in screenshot coordinates\nawait app.activate();                 // raise and focus the window; input normally works without it\n```\n`typeText` inserts; use `setValue` to replace existing text.\n\n### Files\n```js\nawait app.chooseFiles(["/workspace/shots/1.png", "/workspace/shots/2.png"], { trigger: { role: "button", name: "Upload" } });\nawait app.dropFiles(["/workspace/report.pdf"], { name: "Drop files here" });\nconst text = await nodeRepl.readFile("/workspace/texts/description.txt"); // { encoding: null } returns bytes\n```\n`chooseFiles` clicks the trigger (or uses an already open dialog), selects the files in the native file dialog (GTK, desktop portal or Qt) and confirms it; the files may come from different folders. `dropFiles` drops files from outside onto a drop zone, like a file manager.\n\n### Output\n`getApp`, `getAXState`, `find`, `waitFor`, screenshots and inventories print their own results; do not print them again. Use `nodeRepl.write(value)` and `await nodeRepl.emitImage(bytes)` for your own output; `console.log` works too.\n\n### Workflow\n- Batch deterministic actions and one observation in a single call. Prefer queries and `setValue`; verify with `find`/`waitFor` (a confirmation message, a field value, a counter) rather than screenshots.\n- After navigating or submitting, wait for something only the new page has (its heading, a result text): the old page stays readable until the new one has loaded. `find` does not wait; `waitFor` and action queries do.\n- Calls time out after 30 s by default; pass `timeout_ms` for long work.\n- Use screenshots and coordinates only where the tree lacks an element (custom canvases). A tree with `Accessibility source: x11` has no actionable elements.\n- A failed call stops at the failing statement; earlier statements already ran. A syntax error runs nothing.\n- Persist until the requested result is visibly confirmed; otherwise report the concrete blocker.\n'
};

// src/protocol.ts
var MAX_CODE_BYTES = 64 * 1024;
var MAX_TEXT_BYTES = 64 * 1024;
var MAX_IMAGE_BYTES = 4 * 1024 * 1024;
var MAX_RESULT_BYTES = 6 * 1024 * 1024;
var DOCUMENTATION = contract_default.documentation;
var TOOLS = contract_default.tools;

// src/api.ts
var MAX_EMITTED_TREE = 32 * 1024;
var POPUP_WINDOWS = /* @__PURE__ */ new Set(["menu", "popup_menu", "dropdown_menu", "combo", "tooltip", "notification", "dnd"]);
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
var ROLE_ALIASES = {
  button: ["push button", "button", "toggle button", "menu button"],
  textbox: ["entry", "text", "password text", "spin button", "spin box", "search box", "terminal"],
  input: ["entry", "text", "password text", "spin button", "combo box", "search box"],
  field: ["entry", "text", "password text", "spin button", "combo box", "search box"],
  checkbox: ["check box", "check menu item", "toggle button", "switch"],
  radio: ["radio button", "radio menu item"],
  combobox: ["combo box"],
  select: ["combo box", "list box", "list"],
  dropdown: ["combo box", "menu button"],
  link: ["link"],
  menuitem: ["menu item", "check menu item", "radio menu item"],
  option: ["menu item", "list item", "option", "radio menu item", "check menu item"],
  listitem: ["list item"],
  tab: ["page tab"],
  heading: ["heading"],
  dialog: ["dialog", "file chooser", "color chooser", "font chooser"],
  alert: ["alert", "notification"],
  image: ["image", "icon"],
  cell: ["table cell", "cell", "grid cell"],
  row: ["table row", "row", "list item", "tree item"],
  table: ["table", "tree table", "grid"],
  text: ["text", "static", "label", "paragraph", "caption"],
  container: ["panel", "filler", "section", "generic", "group", "unknown"],
  slider: ["slider"],
  spinbutton: ["spin button", "spin box"],
  switch: ["switch", "toggle button"]
};
function isVec2(value) {
  return Array.isArray(value) && value.length === 2 && value.every((item) => typeof item === "number" && Number.isFinite(item));
}
function isQuery(value) {
  return typeof value === "string" || value instanceof RegExp || typeof value === "object" && value !== null && !Array.isArray(value);
}
function describe(value) {
  if (value instanceof RegExp) return String(value);
  if (typeof value === "string") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(describe).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.entries(value).filter(([, item]) => item !== void 0).map(([key, item]) => `${key}:${describe(item)}`).join(",")}}`;
  }
  return String(value);
}
function textMatches(pattern, value) {
  if (pattern === void 0) return true;
  if (pattern instanceof RegExp) {
    pattern.lastIndex = 0;
    return pattern.test(value);
  }
  return value.toLowerCase().includes(String(pattern).toLowerCase());
}
function roleMatches(pattern, node) {
  if (pattern === void 0) return true;
  if (pattern instanceof RegExp) {
    if (textMatches(pattern, node.role)) return true;
    return Object.entries(ROLE_ALIASES).some(([alias, roles]) => roles.includes(node.role) && textMatches(pattern, alias));
  }
  const compact = (value) => value.toLowerCase().replace(/[\s_-]/g, "");
  const wanted = compact(pattern);
  return ROLE_ALIASES[wanted]?.includes(node.role) || compact(node.role) === wanted;
}
function nodeMatches(node, query) {
  if (typeof query === "string" || query instanceof RegExp) return textMatches(query, node.line);
  if (query.id !== void 0 && node.id !== query.id) return false;
  if (!roleMatches(query.role, node)) return false;
  const name = node.name || (TEXT_BLOCKS.has(node.role) ? node.value : "");
  if (!textMatches(query.name, name)) return false;
  if (!textMatches(query.value, node.value)) return false;
  if (!textMatches(query.description, node.description)) return false;
  if (!textMatches(query.context, node.context)) return false;
  if (query.text !== void 0 && !textMatches(query.text, [node.name, node.value, node.description, node.context].join("\n"))) return false;
  for (const state of query.states ?? []) {
    const negated = state.startsWith("!");
    const name2 = (negated ? state.slice(1) : state).toLowerCase();
    if (node.states.includes(name2) === negated) return false;
  }
  return true;
}
function exact(node, query) {
  const pattern = typeof query === "string" ? query : query instanceof RegExp ? void 0 : query.name ?? query.text;
  const name = node.name || (TEXT_BLOCKS.has(node.role) ? node.value : "");
  return typeof pattern === "string" && name.toLowerCase().trim() === pattern.toLowerCase().trim();
}
var TEXT_BLOCKS = /* @__PURE__ */ new Set(["paragraph", "heading", "text", "static", "label", "caption", "block quote", "list item", "table cell"]);
var EDITABLE_ROLES = /* @__PURE__ */ new Set(["combo box", "list box", "slider", "spin button", "spin box", "check box", "radio button", "toggle button", "switch", "page tab list"]);
function suits(node, purpose) {
  if (purpose === "any") return true;
  if (purpose === "edit") return node.states.includes("editable") || EDITABLE_ROLES.has(node.role);
  return !["text", "static", "label", "paragraph", "heading", "caption", "section", "panel", "generic", "filler"].includes(node.role) || node.states.includes("focusable") || node.actions.some((action) => !["", "doDefault", "showContextMenu"].includes(action));
}
function element(node) {
  const result = { id: node.id, role: node.role, name: node.name };
  if (node.value) result.value = node.value;
  if (node.description) result.description = node.description;
  if (node.context) result.context = node.context;
  result.states = node.states;
  if (node.actions.length) result.actions = node.actions.filter(Boolean);
  result.line = `${node.id} ${node.line}`;
  return result;
}
function render(tree) {
  const lines = [`Accessibility source: ${tree.source}`];
  if (tree.notice) lines.push(`[${tree.notice}]`);
  for (const node of tree.nodes) if (!node.folded) lines.push(`${"	".repeat(node.depth)}${node.id} ${node.line}`);
  return lines.join("\n");
}
function limit(text) {
  if (Buffer.byteLength(text) <= MAX_EMITTED_TREE) return text;
  const lines = text.split("\n");
  const kept = [];
  let size = 200;
  for (const line of lines) {
    size += Buffer.byteLength(line) + 1;
    if (size > MAX_EMITTED_TREE) break;
    kept.push(line);
  }
  kept.splice(1, 0, `[Showing ${kept.length - 1} of ${lines.length - 1} lines (output limit). Use app.find(query) or getAXState({ root }) for the rest.]`);
  return kept.join("\n");
}
function baseline(tree) {
  return new Map(tree.nodes.filter((node) => !node.folded).map((node) => [node.id, { line: node.line, parent: node.parent }]));
}
function diff(previous, full) {
  const tree = { ...full, nodes: full.nodes.filter((node) => !node.folded) };
  const current2 = new Map(tree.nodes.map((node) => [node.id, node]));
  const added = new Set(tree.nodes.filter((node) => !previous.has(node.id)).map((node) => node.id));
  const lines = [];
  for (const node of tree.nodes) {
    const before = previous.get(node.id);
    if (added.has(node.id)) {
      if (node.parent !== null && added.has(node.parent)) continue;
      const base = node.depth;
      lines.push(`+ ${node.id} ${node.line}${node.parent !== null ? ` (in ${node.parent})` : ""}`);
      const stack = /* @__PURE__ */ new Set([node.id]);
      for (const child of tree.nodes.slice(tree.nodes.indexOf(node) + 1)) {
        if (child.parent === null || !stack.has(child.parent) || !added.has(child.id)) {
          if (child.depth <= base) break;
          continue;
        }
        stack.add(child.id);
        lines.push(`${"	".repeat(child.depth - base)}+ ${child.id} ${child.line}`);
      }
    } else if (before && (before.line !== node.line || before.parent !== node.parent)) {
      lines.push(`~ ${node.id} ${node.line}${before.parent !== node.parent ? ` (moved to ${node.parent})` : ""}`);
    }
  }
  const removed = [...previous.entries()].filter(([id]) => !current2.has(id));
  const removedIds = new Set(removed.map(([id]) => id));
  for (const [id, entry] of removed) {
    if (entry.parent !== null && removedIds.has(entry.parent)) continue;
    let descendants = 0;
    const pending2 = [id];
    while (pending2.length) {
      const parent = pending2.pop();
      for (const [other, value] of removed) if (value.parent === parent) {
        descendants++;
        pending2.push(other);
      }
    }
    lines.push(`- ${id} ${entry.line}${descendants ? ` (and ${descendants} descendants)` : ""}`);
  }
  const header = `Accessibility source: ${tree.source} \u2014 changes since the previous state (+ added, ~ changed, - removed; getAXState({ disableDiffing: true }) shows everything)`;
  if (!lines.length) return `Accessibility source: ${tree.source}
[No changes since the previous state]`;
  return [header, ...tree.notice ? [`[${tree.notice}]`] : [], ...lines].join("\n");
}
function windowMatches(window, query) {
  if (typeof query === "string" || query instanceof RegExp) {
    return textMatches(query, `${window.app}
${window.title ?? ""}`);
  }
  if (query.windowId !== void 0 && window.id !== query.windowId) return false;
  if (query.app !== void 0 && !textMatches(query.app, window.app)) return false;
  if (query.title !== void 0 && !textMatches(query.title, window.title ?? "")) return false;
  if (query.type !== void 0 && window.window_type !== query.type) return false;
  if (query.modal !== void 0 && !!window.modal !== query.modal) return false;
  return true;
}
function single(list) {
  if (list.length === 1) return list[0];
  const focused = list.filter((window) => window.focused);
  return focused.length === 1 ? focused[0] : void 0;
}
function windowLine(window) {
  const states = [window.window_type && window.window_type !== "normal" ? window.window_type : "", window.modal ? "modal" : "", window.focused ? "focused" : ""].filter(Boolean);
  return `${window.id} ${window.app}${window.title ? ` \u201C${window.title}\u201D` : ""}${states.length ? ` (${states.join(", ")})` : ""}`;
}
function appLine(app) {
  const open = app.windows?.length ? ` \u2014 open: ${app.windows.map((window) => window.id).join(", ")}` : "";
  return `${app.displayName} (${app.id.replace(/\.desktop$/, "")})${open}`;
}
function createCua(native2, write2, emitImage2, requestMeta = () => void 0) {
  let documented = false;
  let documentationRequest;
  function documentation() {
    if (!documented) {
      write2(DOCUMENTATION, "cua.core");
      documented = true;
      documentationRequest = requestMeta();
    }
  }
  async function inventory(op, options = {}) {
    documentation();
    const result = await native2(op);
    const value = result.items ?? result;
    if (options.emit !== false) {
      const lines = op === "windows" ? value.map(windowLine) : op === "apps" ? value.map(appLine) : [JSON.stringify(value)];
      write2(lines.join("\n") || "(none)", "cua.state");
    }
    return value;
  }
  async function windows() {
    return (await native2("windows")).items;
  }
  async function resolveWindow(target, timeoutMs = 0, launch = true) {
    if (target && typeof target === "object" && !(target instanceof RegExp) && "windowId" in target) {
      const id = target.windowId;
      if (!Number.isSafeInteger(id) || id <= 0) throw new Error("getApp requires { windowId } from listWindows(), an app name, or { app, title }.");
      const found = (await windows()).find((window) => window.id === id);
      if (!found) throw new Error(`Window ${id} is unavailable.`);
      return found;
    }
    if (!(typeof target === "string" || target instanceof RegExp || target && typeof target === "object")) {
      throw new Error("getApp requires an app name, a RegExp, { windowId }, or { app, title }.");
    }
    const query = target;
    const deadline = Date.now() + timeoutMs;
    let launched = false;
    while (true) {
      const all = await windows();
      let matching = all.filter((window) => windowMatches(window, query));
      if (matching.length > 1) {
        const main = matching.filter((window) => !POPUP_WINDOWS.has(window.window_type ?? "normal"));
        if (main.length) matching = main;
      }
      if (matching.length === 1) return matching[0];
      if (matching.length > 1) {
        throw new Error(`Several windows match ${describe(query)}; pass { windowId } or a title:
${matching.slice(0, 12).map(windowLine).join("\n")}`);
      }
      if (launch && !launched && (typeof query === "string" || typeof query === "object" && !(query instanceof RegExp) && typeof query.app === "string" && query.title === void 0 && query.windowId === void 0)) {
        const name = String(typeof query === "string" ? query : query.app).toLowerCase();
        const apps = (await native2("apps")).items;
        const candidates = apps.filter((app) => app.displayName.toLowerCase() === name || app.id.toLowerCase().replace(/\.desktop$/, "") === name);
        const loose = candidates.length ? candidates : apps.filter((app) => app.displayName.toLowerCase().includes(name));
        const running = (loose.length === 1 ? loose[0].windows ?? [] : []).filter((window) => all.some((open) => open.id === window.id));
        if (running.length === 1) return all.find((open) => open.id === running[0].id);
        if (running.length > 1) {
          throw new Error(`Several windows of ${loose[0].displayName} are open; pass { windowId } or a title:
${running.slice(0, 12).map(windowLine).join("\n")}`);
        }
        if (loose.length > 1 && !all.some((window) => windowMatches(window, query))) {
          throw new Error(`Several installed apps match ${describe(query)}; pass the exact name:
${loose.slice(0, 10).map((app) => `${app.displayName} (${app.id})`).join("\n")}`);
        }
        if (loose.length === 1) {
          const words = loose[0].displayName.toLowerCase().split(/\W+/).filter((word) => word.length >= 4);
          const waiting = async () => {
            const open = await windows();
            const related = (window) => words.some((word) => `${window.title ?? ""} ${window.app}`.toLowerCase().includes(word));
            const classes = new Set(open.filter(related).map((window) => window.app));
            const dialogs = open.filter((window) => (window.window_type === "dialog" || window.modal) && (related(window) || classes.has(window.app)));
            const dialog2 = single(dialogs);
            if (!dialog2) return void 0;
            write2(`[${loose[0].displayName} is waiting for a dialog; bound to it: ${windowLine(dialog2)}. Answer it, then call getApp again for the main window.]`, "cua.state");
            return dialog2;
          };
          try {
            await native2("launch_app", { app: loose[0].id });
          } catch (error) {
            const dialog2 = await waiting();
            if (dialog2) return dialog2;
            throw error;
          }
          launched = true;
          const launchDeadline = Date.now() + 2e4;
          const before = new Set(all.map((window) => window.id));
          let candidate;
          while (Date.now() < launchDeadline) {
            await sleep(250);
            const fresh = (await windows()).filter((window) => !before.has(window.id) && ["normal", "dialog"].includes(window.window_type ?? "normal"));
            const own = fresh.filter((window) => windowMatches(window, query) || window.app.toLowerCase().includes(name) || name.includes(window.app.toLowerCase()));
            const next = single(own) ?? (Date.now() > launchDeadline - 18500 ? single(fresh) : void 0);
            if (next && candidate?.id === next.id) {
              if (next.modal || next.window_type === "dialog" && next.transient_for) {
                write2(`[${loose[0].displayName} opened with a dialog; bound to it: ${windowLine(next)}. Answer it, then call getApp again for the main window.]`, "cua.state");
              }
              return next;
            }
            candidate = next;
            if (next) await sleep(600);
          }
          const dialog = await waiting();
          if (dialog) return dialog;
          throw new Error(`Launched ${loose[0].displayName}, but no window appeared within 20 s.`);
        }
      }
      if (Date.now() >= deadline) {
        throw new Error(`No open window matches ${describe(query)}. Open windows:
${all.slice(0, 20).map(windowLine).join("\n") || "(none)"}`);
      }
      await sleep(200);
    }
  }
  async function getApp(target, options = {}) {
    documentation();
    let window = await resolveWindow(target);
    let binding = await native2("bind", { windowId: window.id });
    const base = () => ({ windowId: window.id, identity: binding.identity });
    const baselines = /* @__PURE__ */ new Map();
    const byQuery = !(target && typeof target === "object" && !(target instanceof RegExp) && "windowId" in target);
    async function call(op, args = {}) {
      try {
        return await native2(op, args);
      } catch (error) {
        if (!byQuery || !/Bind this window again|window (?:is not visible|was closed|closed during)/i.test(String(error.message))) throw error;
        let next;
        const deadline = Date.now() + 8e3;
        while (!next && Date.now() < deadline) {
          try {
            next = await resolveWindow(target, 0, false);
          } catch (lookup) {
            if (/Several windows/.test(String(lookup.message))) throw lookup;
            await sleep(300);
          }
        }
        if (!next) {
          try {
            next = await resolveWindow(target, 0, true);
          } catch {
            throw error;
          }
        }
        window = next;
        binding = await native2("bind", { windowId: window.id });
        baselines.clear();
        app.windowId = window.id;
        app.window = window;
        write2(`[The window was replaced; now bound to ${windowLine(window)}]`, "cua.state");
        return await native2(op, { ...args, ...base() });
      }
    }
    async function readTree(options2 = {}) {
      const root = options2.root === void 0 ? void 0 : await elementId(options2.root);
      return await call("state", { ...base(), text: true, root, maxNodes: options2.maxNodes, fresh: options2.disableDiffing || void 0 });
    }
    async function candidates(query, fresh = false) {
      const within = typeof query === "object" && !(query instanceof RegExp) ? query.within : void 0;
      const tree = await readTree({ root: within, disableDiffing: fresh });
      return { tree, matches: tree.nodes.filter((node) => nodeMatches(node, query)) };
    }
    function poller() {
      let lastFresh = Date.now();
      return () => {
        if (Date.now() - lastFresh < 1e3) return false;
        lastFresh = Date.now();
        return true;
      };
    }
    async function pick(query, timeoutMs = 5e3, purpose = "any") {
      const deadline = Date.now() + timeoutMs;
      const fresh = poller();
      let first = true;
      while (true) {
        const { tree, matches } = await candidates(query, !first && fresh());
        first = false;
        const index = typeof query === "object" && !(query instanceof RegExp) ? query.index : void 0;
        if (index !== void 0) {
          if (matches[index]) return matches[index];
        } else if (matches.length === 1) {
          return matches[0];
        } else if (matches.length > 1) {
          const parents = new Set(tree.nodes.map((node) => node.parent));
          let narrowed = matches;
          for (const prefer of [
            (node) => suits(node, purpose),
            // An open menu's item rather than its twin in a closed menu.
            (node) => !node.folded,
            (node) => !!node.popup,
            (node) => exact(node, query),
            (node) => parents.has(node.id)
          ]) {
            const kept = narrowed.filter(prefer);
            if (kept.length) narrowed = kept;
            if (narrowed.length === 1) return narrowed[0];
          }
          throw new Error(`${matches.length} elements match ${describe(query)}; add role/name/states, or index (0-based):
${matches.slice(0, 8).map((node) => `${node.id} ${node.line}`).join("\n")}`);
        }
        if (Date.now() >= deadline) {
          throw new Error(`No element matches ${describe(query)} after ${timeoutMs} ms${tree.truncated ? " (the tree was partial; pass within/root)" : ""}. Use app.find() to inspect candidates.`);
        }
        await sleep(200);
      }
    }
    async function elementId(target2, timeoutMs, purpose = "any") {
      if (typeof target2 === "number") {
        if (!Number.isSafeInteger(target2)) throw new Error("Element IDs are integers from the accessibility state.");
        return target2;
      }
      if (isVec2(target2)) throw new Error("This method needs an element (ID or query), not coordinates.");
      if (!isQuery(target2)) throw new Error('Pass an element ID, a query such as { role: "button", name: "Save" }, or [x, y].');
      return (await pick(target2, timeoutMs, purpose)).id;
    }
    async function locate(target2, timeoutMs, purpose = "act") {
      if (isVec2(target2)) return { coordinates: target2 };
      return { elementId: await elementId(target2, timeoutMs, purpose) };
    }
    async function act(target2, timeoutMs, run, purpose = "act") {
      const located = await locate(target2, timeoutMs, purpose);
      try {
        return await run(located);
      } catch (error) {
        if (isQuery(target2) && /no longer exists|was replaced|unknown for this window/.test(String(error.message))) {
          return await run(await locate(target2, timeoutMs, purpose));
        }
        throw error;
      }
    }
    function emitState(key, tree, options2) {
      const full = render(tree);
      if (options2.emit === false) return full;
      const previous = baselines.get(key);
      let shown = full;
      if (previous && !options2.disableDiffing) {
        const changes = diff(previous, tree);
        if (changes.length < full.length * 0.7) shown = changes;
      }
      write2(limit(shown), "cua.state");
      baselines.set(key, baseline(tree));
      return full;
    }
    async function screenshot(options2, text, observation = {}) {
      let region = options2.region;
      if (region !== void 0 && !(Array.isArray(region) && region.length === 4)) region = await elementId(region);
      const root = observation.root === void 0 ? void 0 : await elementId(observation.root);
      const result = await call("state", { ...base(), image: true, text, region, root, maxDimension: options2.maxDimension, maxNodes: observation.maxNodes });
      const bytes = Buffer.from(result.image, "base64");
      let state;
      if (text) state = emitState(describe(observation.root ?? null), result, { ...observation, emit: options2.emit });
      if (options2.emit !== false) {
        await emitImage2(bytes);
        if (result.region || result.scale !== 1) {
          write2(`[Screenshot ${result.width}\xD7${result.height}${result.region ? ` of window region ${result.region.join(",")}` : ""}${result.scale !== 1 ? `, scale ${result.scale}` : ""}. Coordinates read from this image work directly with click/scroll/drag.]`, "cua.state");
        }
      }
      return { state, screenshot: bytes };
    }
    const app = {
      windowId: window.id,
      window,
      getAXState: async (options2 = {}) => emitState(describe(options2.root ?? null), await readTree(options2), options2),
      getScreenshot: async (options2 = {}) => (await screenshot(options2, false)).screenshot,
      getAXStateAndScreenshot: async (options2 = {}) => {
        const result = await screenshot(options2, true, options2);
        return { state: result.state, screenshot: result.screenshot };
      },
      find: async (query, options2 = {}) => {
        if (!isQuery(query)) throw new Error("find expects a string, RegExp or { role, name, text, value, states, within }.");
        const { tree, matches } = await candidates(query);
        if (options2.emit !== false) {
          const shown = Math.max(1, options2.limit ?? 30);
          write2(`${matches.length ? [...matches.slice(0, shown).map((node) => `${node.id} ${node.line}`), ...matches.length > shown ? [`\u2026 ${matches.length - shown} more (pass { limit } or a narrower query)`] : []].join("\n") : `No element matches ${describe(query)}${tree.truncated ? " (the tree was partial)" : ""}`}`, "cua.state");
        }
        return matches.map(element);
      },
      waitFor: async (query, options2 = {}) => {
        if (!isQuery(query)) throw new Error("waitFor expects a string, RegExp or { role, name, text, value, states, within }.");
        const timeout = options2.timeoutMs ?? 1e4;
        if (!Number.isFinite(timeout) || timeout < 0) throw new Error("timeoutMs must be a non-negative number.");
        const deadline = Date.now() + timeout;
        const fresh = poller();
        let first = true;
        while (true) {
          const { matches } = await candidates(query, !first && fresh());
          first = false;
          if (!options2.gone && matches.length) {
            if (options2.emit !== false) write2(`${matches.slice(0, 5).map((node) => `${node.id} ${node.line}`).join("\n")}`, "cua.state");
            return element(matches[0]);
          }
          if (options2.gone && !matches.length) {
            if (options2.emit !== false) write2(`Gone: ${describe(query)}`, "cua.state");
            return void 0;
          }
          if (Date.now() >= deadline) {
            throw new Error(options2.gone ? `waitFor timed out after ${timeout} ms: ${describe(query)} is still present (${matches[0].id} ${matches[0].line})` : `waitFor timed out after ${timeout} ms: nothing matches ${describe(query)}. Use app.find() to inspect candidates.`);
          }
          await sleep(250);
        }
      },
      click: async (target2, options2 = {}) => {
        const { timeoutMs, ...click } = options2;
        if (click.durationMs !== void 0 && (!Number.isSafeInteger(click.durationMs) || click.durationMs < 0)) throw new Error("durationMs must be a non-negative safe integer.");
        await act(target2, timeoutMs, (located) => call("click", { ...base(), ...located, ...click }));
      },
      hover: async (target2, options2 = {}) => {
        await act(target2, options2.timeoutMs, (located) => call("hover", { ...base(), ...located }));
      },
      focus: async (target2, options2 = {}) => {
        await act(target2, options2.timeoutMs, async (located) => {
          if ("coordinates" in located) await call("click", { ...base(), ...located });
          else await call("focus", { ...base(), ...located });
        });
      },
      drag: async (from, to, options2 = {}) => {
        const start = await locate(from, options2.timeoutMs);
        const end = await locate(to, options2.timeoutMs);
        await call("drag", {
          ...base(),
          ..."coordinates" in start ? { from: start.coordinates } : { fromElementId: start.elementId },
          ..."coordinates" in end ? { to: end.coordinates } : { toElementId: end.elementId }
        });
      },
      scroll: async (target2, direction, distance) => {
        if (typeof distance === "number") throw new Error("Linux scroll accepts { pixels }, not pages.");
        if (distance && (!Number.isFinite(distance.pixels) || distance.pixels <= 0)) throw new Error("pixels must be a positive finite number.");
        await act(target2, void 0, (located) => call("scroll", { ...base(), ...located, direction, ...distance ? { pixels: distance.pixels } : {} }));
      },
      scrollIntoView: async (target2, options2 = {}) => {
        await act(target2, options2.timeoutMs, async (located) => {
          if ("coordinates" in located) throw new Error("scrollIntoView needs an element.");
          await call("scroll_into_view", { ...base(), ...located });
        });
      },
      selectText: async (target2, text, options2 = {}) => {
        await act(target2, void 0, async (located) => {
          if ("coordinates" in located) throw new Error("selectText needs an element.");
          await call("select_text", { ...base(), ...located, text, ...options2 });
        });
      },
      setValue: async (target2, value, options2 = {}) => {
        return await act(target2, options2.timeoutMs, async (located) => {
          if ("coordinates" in located) throw new Error("setValue needs an element (ID or query), not coordinates.");
          return await call("set_value", { ...base(), ...located, value });
        }, "edit");
      },
      paste: async (text, options2) => {
        if (options2?.format !== void 0 && options2.format !== "text") throw new Error("Linux paste supports only text format.");
        await call("type_text", { ...base(), text });
      },
      pressKey: async (key, options2 = {}) => {
        if (options2.durationMs !== void 0 && (!Number.isSafeInteger(options2.durationMs) || options2.durationMs < 0)) throw new Error("durationMs must be a non-negative safe integer.");
        await call("press_key", { ...base(), key, ...options2 });
      },
      typeCharacters: async (text) => {
        const result = await call("type_characters", { ...base(), text });
        return { charactersSent: result.charactersSent };
      },
      typeText: async (text, target2, options2 = {}) => {
        if (target2 === void 0 || target2 === null) {
          await call("type_text", { ...base(), text });
          return;
        }
        await act(target2, options2.timeoutMs, async (located) => {
          if ("coordinates" in located) {
            await call("click", { ...base(), ...located });
            await call("type_text", { ...base(), text });
          } else {
            await call("type_text", { ...base(), text, ...located });
          }
        }, "edit");
      },
      performSecondaryAction: async (target2, action) => {
        await act(target2, void 0, async (located) => {
          if ("coordinates" in located) throw new Error("performSecondaryAction needs an element.");
          await call("secondary", { ...base(), ...located, action });
        });
      },
      getBounds: async (target2) => await call("bounds", { ...base(), elementId: await elementId(target2) }),
      chooseFiles: async (paths, options2 = {}) => {
        let trigger = {};
        if (options2.trigger !== void 0) {
          const located = await locate(options2.trigger);
          trigger = "coordinates" in located ? { triggerCoordinates: located.coordinates } : { triggerElementId: located.elementId };
        }
        const result = await call("choose_files", { ...base(), paths, timeoutMs: options2.timeoutMs, ...trigger });
        write2(`Chose ${result.files.length} file(s)${result.dialog ? ` in \u201C${result.dialog}\u201D` : ""}.`, "cua.state");
        return { files: result.files, dialog: result.dialog };
      },
      dropFiles: async (paths, target2, options2 = {}) => {
        const located = await locate(target2, options2.timeoutMs);
        const result = await call("drop_files", { ...base(), paths, ...located });
        write2(`Dropped ${result.files.length} file(s).`, "cua.state");
        return { files: result.files };
      },
      activate: async () => {
        await call("activate", base());
      }
    };
    const initial = await readTree();
    emitState("null", initial, { emit: options.emit });
    return app;
  }
  return {
    getState: (options) => inventory("inventory", options),
    listWindows: (options) => inventory("windows", options),
    listApps: (options) => inventory("apps", options),
    getApp,
    waitForWindow: async (query, options = {}) => {
      documentation();
      const timeout = options.timeoutMs ?? 1e4;
      const deadline = Date.now() + timeout;
      while (true) {
        const matching = (await windows()).filter((window) => windowMatches(window, query));
        if (matching.length) {
          const chosen = single(matching) ?? [...matching].sort((a, b) => b.id - a.id)[0];
          if (options.emit !== false) write2(windowLine(chosen) + (matching.length > 1 ? ` (of ${matching.length} matching windows: focused or newest)` : ""), "cua.state");
          return chosen;
        }
        if (Date.now() >= deadline) throw new Error(`No window matching ${describe(query)} appeared within ${timeout} ms.`);
        await sleep(250);
      }
    },
    computer: {
      target: "linux",
      launch_app: async (input) => {
        await native2("launch_app", input);
      }
    },
    rewriteDocumentation: async () => {
      if (!documented) {
        documentation();
        return;
      }
      const meta = requestMeta();
      if (meta == null || meta !== documentationRequest) {
        write2(DOCUMENTATION, "cua.core");
        documentationRequest = meta;
      }
    }
  };
}

// src/worker.ts
var session = new inspector.Session();
session.connect();
var current;
var execution = new AsyncLocalStorage();
var requestId = 0;
var pending = /* @__PURE__ */ new Map();
function send(value) {
  if (process.connected) process.send?.(value);
}
function emit(content, name) {
  if (!current || execution.getStore() !== current.id) throw new Error("No active JavaScript execution");
  send({ type: "content", id: current.id, content, name });
}
async function native(op, args = {}) {
  if (!current || execution.getStore() !== current.id) throw new Error("CUA operation outside an active js call");
  const id = ++requestId;
  const promise = new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
  send({ type: "native", id: current.id, requestId: id, request: { op, args } });
  return promise;
}
var pendingConsoleNewline = false;
var write = (value, name) => {
  if (pendingConsoleNewline) {
    emit({ type: "text", text: "\n" });
    pendingConsoleNewline = false;
  }
  emit({ type: "text", text: typeof value === "string" ? value : inspect(value) }, name);
};
var consoleLine = (...values) => {
  write(format(...values));
  pendingConsoleNewline = true;
};
var emitImage = async (value) => {
  let mimeType;
  if (typeof value === "object" && value !== null && "bytes" in value) {
    const input = value;
    mimeType = input.mimeType;
    value = input.bytes;
  }
  if (typeof value === "string") {
    if (value.startsWith("file:")) value = await readFile(new URL(value));
    else {
      const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/]*={0,2})$/.exec(value);
      if (!match) throw new Error("emitImage expects a data URL, file URL, image bytes, or { bytes, mimeType }.");
      mimeType = match[1];
      value = Buffer.from(match[2], "base64");
    }
  }
  if (!(value instanceof Uint8Array)) throw new Error("emitImage expects a data URL, file URL, image bytes, or { bytes, mimeType }.");
  const data = Buffer.from(value);
  mimeType ??= data.subarray(0, 4).toString("hex") === "89504e47" ? "image/png" : data.subarray(0, 3).toString("hex") === "ffd8ff" ? "image/jpeg" : data.subarray(0, 4).toString() === "RIFF" && data.subarray(8, 12).toString() === "WEBP" ? "image/webp" : void 0;
  if (!mimeType || !["image/png", "image/jpeg", "image/webp"].includes(mimeType)) throw new Error("Unsupported image format.");
  emit({ type: "image", mimeType, data: data.toString("base64"), _meta: { "codex/imageDetail": "original" } });
};
var FILE_ROOTS = [.../* @__PURE__ */ new Set(["/workspace", "/tmp", process.cwd()])];
var MAX_FILE_BYTES = 32 * 1024 * 1024;
async function readWorkspaceFile(file, options = {}) {
  if (typeof file !== "string" || !file) throw new Error("readFile expects a file path.");
  const resolved = await realpath(path.resolve(process.cwd(), file));
  if (!FILE_ROOTS.some((root) => resolved === root || resolved.startsWith(root.endsWith("/") ? root : `${root}/`))) {
    throw new Error(`readFile is limited to ${FILE_ROOTS.join(", ")}.`);
  }
  const info = await stat(resolved);
  if (!info.isFile()) throw new Error(`${file} is not a regular file.`);
  if (info.size > MAX_FILE_BYTES) throw new Error(`${file} exceeds 32 MiB.`);
  const data = await readFile(resolved);
  return options.encoding === null ? new Uint8Array(data) : data.toString(options.encoding ?? "utf8");
}
var cua = createCua(native, write, emitImage, () => current?.context.request_meta);
Object.assign(globalThis, {
  cua,
  nodeRepl: Object.freeze({ write, emitImage, readFile: readWorkspaceFile, get requestMeta() {
    return current?.context.request_meta;
  } }),
  console: Object.freeze({ log: consoleLine, info: consoleLine, debug: consoleLine, error: consoleLine, warn: consoleLine, dir: (value) => consoleLine(inspect(value)) })
});
process.on("message", (message) => {
  if (message.type === "native_result") {
    const entry = pending.get(message.requestId);
    if (!entry) return;
    pending.delete(message.requestId);
    if (message.error) entry.reject(new Error(message.error));
    else entry.resolve(message.value);
    return;
  }
  if (message.type !== "execute" || current) return;
  current = message;
  pendingConsoleNewline = false;
  execution.run(message.id, () => session.post("Runtime.evaluate", {
    expression: message.code,
    replMode: true,
    awaitPromise: true,
    timeout: message.timeout,
    objectGroup: message.id
  }, (error, rawResponse) => {
    const response = rawResponse;
    const id = current?.id;
    let failure = error?.message;
    if (response?.exceptionDetails) {
      const description = response.exceptionDetails.exception?.description ?? response.exceptionDetails.text;
      failure = description.split("\n    at ")[0].replace(/^(?:Uncaught )?(?:\w*Error): /, "");
      const token = /^Unexpected token '(.*)'$/.exec(failure);
      if (response.exceptionDetails.exception?.className === "SyntaxError" && token) {
        const line = response.exceptionDetails.lineNumber + 1;
        const column = response.exceptionDetails.columnNumber;
        failure = `[${line}:${column}-${line}:${column + token[1].length}]: Unexpected token: '${token[1]}'`;
      }
      if (response.exceptionDetails.exception?.className === "SyntaxError") {
        failure += " \u2014 nothing from this call ran, so none of its declarations exist. Fix the syntax and resend the whole call.";
      }
    }
    if (pending.size && !failure) failure = "Await every CUA operation before js returns.";
    current = void 0;
    for (const entry of pending.values()) entry.reject(new Error("JavaScript execution ended"));
    pending.clear();
    session.post("Runtime.releaseObjectGroup", { objectGroup: message.id });
    session.post("Runtime.discardConsoleEntries");
    send({ type: "done", id, error: failure });
  }));
});
process.on("disconnect", () => process.exit(0));
