import { createRequire as __createRequire } from 'node:module'; const require = __createRequire(import.meta.url);

// src/worker.ts
import inspector from "node:inspector";
import { AsyncLocalStorage } from "node:async_hooks";
import { inspect } from "node:util";

// src/protocol.ts
var MAX_CODE_BYTES = 64 * 1024;
var MAX_TEXT_BYTES = 64 * 1024;
var MAX_IMAGE_BYTES = 4 * 1024 * 1024;
var MAX_RESULT_BYTES = 6 * 1024 * 1024;
var DOCUMENTATION = `Computer use runs on the workspace Linux desktop. State persists between js calls in this run. A new turn or js_reset discards JavaScript bindings, not applications.
Start with exactly one entry point: await cua.getState(), await cua.listWindows(), or var app = await cua.getApp({windowId: ID_FROM_INVENTORY}). Read its output before acting.
Use only observed window IDs and element IDs. getApp returns API documentation and its first AX state. It does not activate the window. Call await app.activate() explicitly before coordinate or keyboard input.
Methods:
cua.getState(); cua.listApps(); cua.listWindows(); cua.getApp({windowId}); cua.rewriteDocumentation();
app.activate(); app.getAXState(); app.getScreenshot(); app.getAXStateAndScreenshot();
app.click(elementId | [x,y], {mouseButton?: 'left'|'right'|'middle',clickCount?:1|2});
app.pressKey('Control_L+a'); app.typeText(text, optionalElementId);
app.scroll(elementId | [x,y], 'up'|'down'|'left'|'right', {pixels: 300});
app.drag([startX,startY],[endX,endY]); app.performSecondaryAction(elementId, actionName);
Coordinates are relative to the latest emitted window screenshot. Observe again after UI changes, before another coordinate action. Element IDs belong to the latest AX snapshot of their window. Report stale references by observing again, never guessing.
AX source x11 is a limited fallback, not a full accessibility tree. Use its screenshot when elements are unavailable. Browser DOM APIs are not enabled; use the separate browser plugin for DOM automation.
Observation methods emit their text/images automatically. nodeRepl.write(value) emits additional text; await nodeRepl.emitImage(bytes) emits an image. Do not wrap observation methods in emitImage.
Await every CUA operation. Unawaited calls cannot continue after js ends. On timeout the worker is reset; effects may already have occurred. Reobserve before recovery, never blindly replay actions.`;

// src/api.ts
function createCua(native2, write2, emitImage2) {
  let documented = false;
  const documentation = () => {
    if (!documented) {
      write2(DOCUMENTATION);
      documented = true;
    }
  };
  async function inventory(op, options = {}) {
    documentation();
    const result = await native2(op);
    const value = result.items ?? result;
    if (options.emit !== false) write2(value);
    return value;
  }
  async function getApp(target) {
    if (!target || !Number.isSafeInteger(target.windowId) || target.windowId <= 0) throw new Error("Linux getApp requires {windowId} from listWindows().");
    documentation();
    const binding = await native2("bind", { windowId: target.windowId });
    let snapshotId = "";
    let screenshotId = "";
    const base = () => ({ windowId: target.windowId, identity: binding.identity, snapshotId });
    const resolveTarget = (value) => Array.isArray(value) ? { coordinates: value, screenshotId } : { elementId: value };
    async function observe(image, text, options = {}) {
      const result = await native2("state", { ...base(), image, text });
      if (text) snapshotId = result.snapshotId;
      if (image) screenshotId = result.screenshotId;
      const bytes = result.image ? Buffer.from(result.image, "base64") : void 0;
      if (options.emit !== false) {
        if (text) write2(result.state);
        if (bytes) {
          write2({ screenshot: { id: result.screenshotId, width: result.width, height: result.height, windowId: target.windowId, generation: result.generation } });
          await emitImage2(bytes);
        }
      }
      return { state: result.state, screenshot: bytes };
    }
    const app = {
      windowId: target.windowId,
      activate: () => native2("activate", base()).then(() => void 0),
      getAXState: async (options) => (await observe(false, true, options)).state,
      getScreenshot: async (options) => (await observe(true, false, options)).screenshot,
      getAXStateAndScreenshot: (options) => observe(true, true, options),
      click: async (value, options = {}) => {
        await native2("click", { ...base(), ...resolveTarget(value), ...options });
      },
      pressKey: async (key) => {
        await native2("press_key", { ...base(), key });
      },
      typeText: async (text, elementId) => {
        await native2("type_text", { ...base(), text, elementId });
      },
      scroll: async (value, direction, distance = { pixels: 300 }) => {
        await native2("scroll", { ...base(), ...resolveTarget(value), direction, pixels: distance.pixels });
      },
      drag: async (from, to) => {
        await native2("drag", { ...base(), from, to, screenshotId });
      },
      performSecondaryAction: async (elementId, action) => {
        await native2("secondary", { ...base(), elementId, action });
      }
    };
    await app.getAXState();
    return app;
  }
  return Object.freeze({
    getState: (options) => inventory("inventory", options),
    listWindows: (options) => inventory("windows", options),
    listApps: (options) => inventory("apps", options),
    getApp,
    rewriteDocumentation: async () => {
      documented = false;
      documentation();
    }
  });
}

// src/worker.ts
var session = new inspector.Session();
session.connect();
var current;
var execution = new AsyncLocalStorage();
var requestId = 0;
var pending = /* @__PURE__ */ new Map();
function send(value) {
  if (process.connected) process.send?.(value);
}
function emit(content) {
  if (!current || execution.getStore() !== current.id) throw new Error("No active JavaScript execution");
  send({ type: "content", id: current.id, content });
}
async function native(op, args = {}) {
  if (!current || execution.getStore() !== current.id) throw new Error("CUA operation outside an active js call");
  const id = ++requestId;
  const promise = new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
  send({ type: "native", id: current.id, requestId: id, request: { op, args } });
  return promise;
}
var write = (value) => emit({ type: "text", text: typeof value === "string" ? value : inspect(value, { depth: 5, maxArrayLength: 100, maxStringLength: 16e3 }) });
var emitImage = async (value) => {
  if (!(value instanceof Uint8Array)) throw new Error("emitImage expects screenshot bytes");
  const data = Buffer.from(value);
  const mimeType = data[0] === 137 && data[1] === 80 ? "image/png" : "image/jpeg";
  emit({ type: "image", mimeType, data: data.toString("base64") });
};
Object.assign(globalThis, {
  cua: createCua(native, write, emitImage),
  nodeRepl: Object.freeze({ write, emitImage }),
  console: Object.freeze({ log: (...values) => write(values.length === 1 ? values[0] : values), error: (...values) => write(values), warn: (...values) => write(values) })
});
process.on("message", (message) => {
  if (message.type === "native_result") {
    const entry = pending.get(message.requestId);
    if (!entry) return;
    pending.delete(message.requestId);
    if (message.error) entry.reject(new Error(message.error));
    else entry.resolve(message.value);
    return;
  }
  if (message.type !== "execute" || current) return;
  current = message;
  execution.run(message.id, () => session.post("Runtime.evaluate", {
    expression: message.code,
    replMode: true,
    awaitPromise: true,
    timeout: message.timeout,
    objectGroup: message.id
  }, (error, rawResponse) => {
    const response = rawResponse;
    const id = current?.id;
    let failure = error?.message;
    if (response?.exceptionDetails) failure = response.exceptionDetails.exception?.description ?? response.exceptionDetails.text;
    if (pending.size && !failure) failure = "Await every CUA operation before js returns.";
    current = void 0;
    for (const entry of pending.values()) entry.reject(new Error("JavaScript execution ended"));
    pending.clear();
    session.post("Runtime.releaseObjectGroup", { objectGroup: message.id });
    session.post("Runtime.discardConsoleEntries");
    send({ type: "done", id, error: failure });
  }));
});
process.on("disconnect", () => process.exit(0));
