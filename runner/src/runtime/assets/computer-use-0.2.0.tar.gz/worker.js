import { createRequire as __createRequire } from 'node:module'; const require = __createRequire(import.meta.url);

// src/worker.ts
import inspector from "node:inspector";
import { AsyncLocalStorage } from "node:async_hooks";
import { format, inspect } from "node:util";
import { readFile } from "node:fs/promises";

// src/contract.json
var contract_default = {
  version: "0.1.2",
  surfaces: [
    "computer"
  ],
  tools: [
    {
      name: "js",
      description: 'Control native apps or browsers on the user\u2019s computer by reading or operating UI. Prefer purpose-built skills, connectors, APIs, or CLIs when available.\n\nOn the first invocation of `cua_repl`, or after resetting it, execute exactly one of the API calls shown below, optionally assigning its result to a variable. Do not add other API calls, waits, or snapshots to that invocation.\nThe tool result will include documentation and, when creating or selecting a tab or selecting an app, its initial UI state. Selecting a browser does not open a tab. Read that result before continuing.\nUse only APIs described in the tool instructions or returned documentation.\n\nWhen you need an inventory of available apps, browsers, and tabs, get a snapshot of all enabled surfaces. Otherwise, use the relevant entry point below:\n\n```javascript\nawait cua.getState();\n```\n\nBrowser APIs are disabled.\n\nIf the user specifies an app to use, get the app by name, bundle ID, or path:\n\n```javascript\nlet app = await cua.getApp("Example App");\n```\n\nTo add other content to the tool result, use `nodeRepl.write(value)` for text or other values and `await nodeRepl.emitImage(image)` for images. The APIs listed above already display their documentation or UI state; do not wrap their results in `write` or `emitImage`.\n\nIf your context begins with a summary of an existing computer use task, call `await cua.rewriteDocumentation()` before continuing the computer use task to ensure you have a complete view of the necessary documentation.',
      inputSchema: {
        type: "object",
        properties: {
          code: {
            description: "JavaScript to execute using the initialized cua_repl runtime.",
            type: "string"
          },
          timeout_ms: {
            description: "Optional execution timeout in milliseconds. Defaults to 30000 (30 seconds) when omitted.",
            minimum: 1,
            type: "integer"
          },
          title: {
            description: "Short user-facing description of what the code does.",
            maxLength: 80,
            minLength: 1,
            type: "string"
          }
        },
        required: [
          "code"
        ],
        additionalProperties: false
      }
    },
    {
      name: "js_reset",
      description: "Reset the persistent cua_repl JavaScript session. All JavaScript bindings are discarded. The next cua_repl.js call initializes a fresh runtime for the enabled surfaces. This does not close browser tabs or native apps, or erase their state.",
      inputSchema: {
        type: "object",
        properties: {},
        additionalProperties: false
      },
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        openWorldHint: false
      }
    },
    {
      name: "turn_ended",
      description: "Notify trusted libraries that a Codex turn ended. Repeated notifications for the same session and turn are ignored.",
      inputSchema: {
        type: "object",
        properties: {
          hook_event_name: {
            minLength: 1,
            type: "string"
          },
          session_id: {
            minLength: 1,
            type: "string"
          },
          turn_id: {
            minLength: 1,
            type: "string"
          }
        },
        required: [
          "hook_event_name",
          "session_id",
          "turn_id"
        ],
        additionalProperties: false
      },
      annotations: {
        idempotentHint: true
      },
      _meta: {
        ui: {
          visibility: []
        }
      }
    }
  ],
  documentation: '## Computer Use\n\nControl native apps and browsers on the user\u2019s computer by reading or operating UI. Prefer purpose-built connectors, APIs, or CLIs when available.\n\n- Use `cua_repl` (JavaScript) for all UI actions.\n- Do not use other technologies besides `cua_repl` for computer interactions, unless specifically requested by the user (e.g. AppleScript, `osascript`, JXA, System Events, CGEvent synthesis).\n- Prefer a dedicated plugin or skill when it can complete the task; use Computer Use for interactions that are not exposed through a more specific interface.\n- `cua_repl` state is persistent across calls\n- If you create a tab or get an app, the initial UI state is automatically included in the tool result.\n\n## API\n\n```typescript\ntype Vec2 = [x: number, y: number];\ntype ObservationOptions = { emit?: boolean };\ntype StateOptions = ObservationOptions & { disableDiffing?: boolean };\ntype ScreenshotRegion = {\n  id: string;\n  zIndex: number;\n  bytes: Uint8Array;\n  originX?: number;\n  originY?: number;\n  width?: number;\n  height?: number;\n};\ntype StateAndScreenshot = {\n  state: string;\n  screenshot?: Uint8Array;\n  screenshots?: ScreenshotRegion[];\n};\ntype ScreenshotInputOptions = { screenshotId?: string }; // Windows only\ntype AppClickOptions = ClickOptions & ScreenshotInputOptions;\ntype AppScrollOptions = { pixels: number } & ScreenshotInputOptions;\ntype PasteOptions = { format?: "text" | "md" | "html" };\ntype ClickOptions = {\n  mouseButton?: MouseButton;\n  clickCount?: number;\n  key?: string;\n  durationMs?: number;\n};\ntype PressKeyOptions = { durationMs?: number };\ntype SelectTextOptions = {\n  prefix?: string;\n  suffix?: string;\n  selectionType?: SelectionType;\n};\ntype Direction = "up" | "down" | "left" | "right" | "u" | "d" | "l" | "r";\ntype SelectionType = "text" | "cursor_before" | "cursor_after";\ntype MouseButton = "left" | "right" | "middle" | "l" | "r" | "m";\n\ninterface Target<ScreenshotResult = Uint8Array | ScreenshotRegion[]> {\n  getAXState(options?: StateOptions): Promise<string>;\n  getScreenshot(options?: ObservationOptions): Promise<ScreenshotResult>;\n  getAXStateAndScreenshot(options?: StateOptions): Promise<StateAndScreenshot>;\n  click(target: number | Vec2, options?: ClickOptions): Promise<void>;\n  drag(from: Vec2, to: Vec2): Promise<void>;\n  scroll(target: number | Vec2, direction: Direction, pages?: number): Promise<void>;\n  selectText(elementIndex: number, text: string, options?: SelectTextOptions): Promise<void>;\n  setValue(elementIndex: number, value: string): Promise<void>;\n  performSecondaryAction(elementIndex: number, action: string): Promise<void>;\n}\n\ntype AppInfo = {\n  id: string;\n  displayName?: string;\n  lastUsedDate?: string;\n  useCount?: number;\n  isRunning?: boolean;\n  windows?: WindowInfo[];\n};\ntype WindowInfo = { id: number; app: string; title?: string };\n\ninterface App extends Target {\n  click(target: number | Vec2, options?: AppClickOptions): Promise<void>;\n  drag(from: Vec2, to: Vec2, options?: ScreenshotInputOptions): Promise<void>;\n  scroll(\n    target: number | Vec2,\n    direction: Direction,\n    distance?: number | AppScrollOptions,\n  ): Promise<void>;\n  paste(text: string, options?: PasteOptions): Promise<void>;\n  pressKey(key: string, options?: PressKeyOptions): Promise<void>;\n  // Type at current focus, or pass a field index from getAXState() to target it (Linux).\n  typeText(text: string, elementIndex?: number): Promise<void>;\n  // Send printable keys to current focus without pasting or finding a text field (Linux only).\n  typeCharacters?(text: string): Promise<{ charactersSent: number }>;\n}\n\ntype BrowserInfo = {\n  id: string;\n  name?: string;\n  family?: string;\n  type?: "iab" | "extension" | "cdp" | "mcpapps";\n  profileName?: string;\n  metadata?: { extensionInstanceId?: string; codexSessionId?: string };\n};\n\ntype BrowserTabInfo = {\n  id: string;\n  providerTabId?: string;\n  title?: string;\n  url?: string;\n};\n\ninterface Browser {\n  readonly browserId: string;\n  documentation(): Promise<string>;\n}\n\ninterface BrowserProvider {\n  list(): Promise<BrowserInfo[]>;\n  get(id: string): Promise<Browser>;\n}\n\ninterface BrowserState extends BrowserInfo {\n  tabs: BrowserTabInfo[];\n}\n\ntype TabInfo = {\n  id: string;\n  providerTabId?: string;\n  browserId: string;\n  title?: string;\n  url?: string;\n};\n\ntype State = {\n  apps: AppInfo[];\n  browsers: BrowserState[];\n  errors?: string[]; // Inventory failures; the other inventory remains usable.\n};\n\ntype BrowserOptions = { browser?: string };\ntype GetBrowserOptions = { id?: string; extensionInstanceId?: string; url?: string };\ntype CreateBrowserTabOptions = { visible?: boolean; sessionName?: string };\n\n/** Native input wrappers throw on DOM-only tabs. Use documented Playwright locators instead. */\ninterface Tab extends Target<Uint8Array> {\n  paste(elementIndex: number | null, text: string, options?: PasteOptions): Promise<void>;\n  pressKey(elementIndex: number | null, key: string, options?: PressKeyOptions): Promise<void>;\n  typeText(elementIndex: number | null, text: string): Promise<void>;\n  readonly id: string;\n  goto?(url: string): Promise<void>;\n  back?(): Promise<void>;\n  forward?(): Promise<void>;\n  reload?(): Promise<void>;\n  close?(): Promise<void>;\n  markDeliverable?(): Promise<void>;\n  markHandoff?(): Promise<void>;\n}\n\ndeclare const cua: {\n  getState(options?: ObservationOptions): Promise<State>;\n  computer: {\n    target: "linux" | "mac" | "windows";\n    launch_app?(input: { app: string }): Promise<void>;\n  };\n\n  getApp(target: string | { windowId: number }): Promise<App>;\n  listApps(options?: ObservationOptions): Promise<AppInfo[]>;\n  listWindows?(options?: ObservationOptions): Promise<WindowInfo[]>;\n\n  /** Select without opening a tab. Use the returned browserId with createBrowserTab. */\n  getBrowser(options?: GetBrowserOptions): Promise<Browser>;\n  /** Apply options before opening the tab; omitted settings stay unchanged, unsupported settings throw. */\n  createBrowserTab(\n    browserId: string,\n    url?: string,\n    options?: CreateBrowserTabOptions,\n  ): Promise<Tab>;\n  /** Bind an existing tab; a string is a tab ID. */\n  getTab(\n    reference: string | { mention: string } | { url: string },\n    options?: BrowserOptions,\n  ): Promise<Tab>;\n  listBrowsers(options?: ObservationOptions): Promise<BrowserInfo[]>;\n  listTabs(options?: BrowserOptions & ObservationOptions): Promise<TabInfo[]>;\n};\n```\n\nMCP App tabs support DOM-based interaction. Use `cua.getTab()` to bind an existing app tab; `createBrowserTab()` cannot create one. Navigation and tab lifecycle methods are optional. Use only methods listed in the returned browser documentation.\n\nWhen `dot` appears in the browser inventory, it gives access to tabs on Dot\'s active main thread. `iab` uses the current chat\'s tabs. Select Dot with `await cua.getBrowser({ id: "dot" })`, list its tabs with `await cua.listTabs({ browser: "dot" })`, or create one with `await cua.createBrowserTab("dot", url)`. `await cua.getTab(tabId, { browser: "dot" })` claims an existing tab for the current thread before reading it. Listing tabs does not claim them.\n\nFor DOM-only tabs, `getAXState()` uses a DOM snapshot without numeric element indices. `getScreenshot()` uses the tab screenshot API. Disabled observation APIs report an error. Native input wrappers remain present but throw before input. Use the documented Playwright locators to click controls and fill fields.\n\n## Native apps\n\nOn macOS, use `cua.getApp("Example App")` with an app name, path, or bundle ID. On Linux and Windows, use `cua.getApp({ windowId: 123 })` with an exact open window ID from the app inventory. If an app has multiple windows, use their titles to choose the requested one. Do not choose the first window without checking it.\n\n`cua.listWindows()` is available on Linux and Windows and includes open windows that have no app entry. If the requested app has no open window, launch its inventory ID with `await cua.computer.launch_app({ app: appId })`, then refresh the inventory and select a window. `getApp` does not launch apps on Linux or Windows.\n\nLinux input stays bound to the selected window. Sky sends it without activating that window or moving the desktop pointer. The app can still activate a new window or grab the pointer during a held click, drag, or menu interaction. Coordinates are relative to the selected window. Windows input activates the selected window. Get a fresh Windows screenshot before coordinate actions. With one region, the bound app uses that screenshot\'s coordinate mapping until the next observation; an AX-only observation clears it. With multiple regions, pass the matching `screenshotId` for each coordinate action. Coordinates are relative to that region, including both endpoints of a drag. Element-index actions do not take a screenshot ID.\n\nLinux app coordinate clicks support `durationMs`, a non-negative safe integer giving the milliseconds\nto hold the mouse button down for each click. For example,\n`await app.click([640, 360], { mouseButton: "right", durationMs: 2000 })` holds the right button for\ntwo seconds before releasing it. The same option works for left clicks and keeps the existing\nbound-window routing. Timed Linux clicks require window-relative coordinates, not an element index.\n`performSecondaryAction` invokes a named accessibility action; it does not provide a timed\nmouse-button press.\n\nLinux app coordinate clicks also support `key`, a key chord held during the mouse click using the\nsame format as `pressKey`. For example, `await app.click([640, 360], { key: "shift" })` performs\nShift+left-click. The chord is released between clicks and can be combined with `durationMs`.\nLinux clicks with `key` require window-relative coordinates. Windows native apps reject `key`\nand `durationMs` options.\n\n### Windows screenshot regions\n\nA window and its transient UI (for example, a menu) can produce separate images.\nInspect the displayed images and their IDs, then select the region containing the target:\n\n```typescript\nconst regions = await app.getScreenshot();\n// Use an actual ID from that observation; "menu-region-id" is a placeholder.\nawait app.click([40, 20], { screenshotId: "menu-region-id" });\nawait app.drag([10, 20], [50, 60], { screenshotId: "menu-region-id" });\nawait app.scroll([40, 20], "down", { pixels: 120, screenshotId: "menu-region-id" });\n```\n\nOmitting the ID with multiple regions, or supplying an ID absent from the latest screenshot observation,\nfails before input is sent. A single-region observation continues to support coordinate actions without an ID.\n`screenshotId` is a Windows-only option.\n\n## Workflow\n\nAfter performing one or more UI actions, call `getAXState()` before deciding what to do next. This keeps you in the current UI state and forces you to re-derive fresh element indices from the latest accessibility text instead of reusing stale ones.\nFor token efficiency, when appropriate, the accessibility tree will be returned as a diff from the most previous accessibility tree, listing only the elements that were removed, added, or changed. Prefer this default diff output; pass `{ disableDiffing: true }` only when you need a fresh full accessibility tree. After a screenshot-only observation, request a full tree before relying on accessibility indexes again.\nLinux and Windows always return full accessibility state. Linux reports the tree source. `at_spi` elements support the actions listed in the tree; `x11` fallback elements are observation-only, so use a screenshot and window-relative coordinates for input.\nMinimize model and tool round trips while retaining fresh UI state:\n\n- Batch deterministic actions and the resulting `getAXState()` into one call. You may interact with the UI and return the updated state in that same call, so this does not require a separate tool call.\n- Calling `cua.getApp(...)`, `cua.getTab(...)`, and `cua.createBrowserTab(...)` returns app or tab bindings and automatically displays the latest AX state after they run.\n- For `chrome://newtab` (with or without a trailing slash) and Orbit\u2019s signed new-tab extension page, `cua.getTab(...)` displays tab metadata without reading or changing the new-tab page. Use the returned tab\'s `goto(url)` to navigate to an allowed website.\n- If a standalone `getAXState()` reports no accessibility-tree change, do not immediately repeat it without an intervening action. Use `getScreenshot()`, `getAXStateAndScreenshot()`, or `{ disableDiffing: true }` only when you can identify missing context that representation should provide.\n- Prefer a directly relevant result already visible in the current state over opening broader intermediate UI such as \u201CShow All.\u201D\n- Once the requested result is visibly present, stop exploring and respond.\n  Perform one or more actions, and then fetch the latest state:\n\n```typescript\nawait target.click(42);\nawait target.setValue(42, "openai.com");\nawait tab.typeText(42, "hello");\nawait tab.pressKey(42, "Return");\nawait target.scroll(42, "down", 1);\nawait target.scroll([640, 480], "down", 1);\nawait target.selectText(42, "hello");\nawait target.performSecondaryAction(42, "Expand");\nawait target.getAXState();\n```\n\n## Output\n\n- For text output, use `nodeRepl.write(...)`. The API accepts strings and other values. Use `JSON.stringify(...)` when you want JSON.\n- For image output, use `nodeRepl.emitImage(...)`. The API accepts data or file URLs, PNG/JPEG/WebP bytes, or `{ bytes, mimeType }`.\n- The following APIs output their result internally, calling `nodeRepl.write(...)` and/or `nodeRepl.emitImage(...)` will duplicate the output: `getAXState()`, `getScreenshot()`, `getAXStateAndScreenshot()`, `cua.getState()`, `cua.getApp(...)`, `cua.getTab(...)`, `cua.createBrowserTab(...)`, `cua.listApps()`, `cua.listBrowsers()`, and `cua.listTabs()`. Pass `{ emit: false }` to observation and discovery methods to disable their result output. First-use documentation is still displayed. `cua.getBrowser()` automatically displays its first-use documentation; do not write the returned browser object or reread its documentation.\n- `cua.listWindows()` also displays its result unless `emit: false`. Windows screenshot methods always display images through Sky and reject `emit: false` before capture. With one region, `getScreenshot()` returns image bytes and `getAXStateAndScreenshot()` returns `{ state, screenshot }`. With multiple regions, `getScreenshot()` returns a `ScreenshotRegion[]` and `getAXStateAndScreenshot()` returns `{ state, screenshots }`. Every region is displayed once, followed by its screenshot ID in display order; do not emit the images again. Use a returned ID for coordinate input and refresh it after the next observation.\n\n## Notes\n\n- For browser tabs, `typeText`, `paste`, and `pressKey` take an optional element index as their first argument and focus that element before sending input. Pass `null` to use the currently focused element.\n- By default, prefer element-index actions over coordinate actions for efficiency when an accessibility element is available. Follow explicit task-specific instructions that require a different documented interaction method, such as using screenshots and coordinate clicks instead of DOM or accessibility-tree interactions. For native apps and tabs that support coordinate input, use screenshots and coordinates when AX actions fail. For DOM-only tabs, use Playwright locators. You can also get a screenshot if you need visual context.\n- macOS app `paste` uses the system pasteboard then restores the user\'s previous clipboard contents. Linux and Windows app `paste` support only `text` and use the platform\'s native text input. Browser `paste` does not restore clipboard contents, and its `md` format inserts Markdown source as plain text. Specify `text`, `md`, or `html` explicitly where supported. Prefer `paste` for formatted content and multiline text.\n- On Linux, if you can see the intended field has focus but `typeText` cannot identify it, use `await app.typeCharacters("20")`. It sends printable keys to the bound window without clicking, pasting, or checking which field has focus. Inspect the result before sending more. If a previous attempt entered a prefix, send only the missing text. Use `pressKey` for Return, Tab, and shortcuts.\n- Native app `scroll` accepts a page count on macOS. On Linux, omit the distance for the native default or pass `{ pixels: 500 }`. On Windows, pass a coordinate target and `{ pixels: 500 }`; element targets and page counts are unsupported. Linux element clicks support one left or right click. Use coordinates for other click options.\n- `selectText` is unavailable on Linux and Windows. `setValue` is unavailable on Linux. These methods throw before sending input. Use the supported bound actions to edit the UI and verify the result.\n- If the UI is not behaving as expected, try fetching the latest `getAXState()` to make sure you have the latest context.\n- `performSecondaryAction()` is for invoking an accessibility action that an element exposes besides a normal click, such as expanding a disclosure row, showing a menu, incrementing a control, or cancelling something. It requires an action actually exposed for that element in the accessibility text. Do not guess action names.\n- `selectText()` selects matching text in an editable element. Use `prefix` and `suffix` to disambiguate repeated matches, and `selectionType` to choose whether to select the text itself or place the cursor before or after it.\n- `pressKey()` presses a key or key combination, including modifier and navigation keys. It supports xdotool-style key syntax. Examples: `"a"`, `"Return"`, `"Tab"`, `"super+c"`, `"Up"`, and `"KP_0"` for numpad `0`.\n- `click` holds each mouse press for `durationMs`; macOS apps and browser tabs hold `key` across the full click sequence.\n- On macOS, `cua.getApp(...)` accepts an app\'s display name, full app path, or bundle identifier and launches the app in the background if needed. If display-name resolution fails, retry with the app\'s bundle identifier from `cua.listApps()`.\n- `getAXState()`, `getScreenshot()` and `getAXStateAndScreenshot()` automatically wait an appropriate amount of time before capturing new state. In order to complete the task as quickly as possible, don\u2019t pause or delay (ex: `setTimeout(...)`) before getting UI state. Instead, rely on the internal wait.\n\nPersist until the request is fully completed end-to-end. Attempting an action is not completion: verify that the returned UI state visibly shows the requested result. If an action leaves the state unchanged, produces no results, or only reaches an intermediate page, try another approach. Respond only after the requested page, information, or state is visibly present, or explain a concrete blocker you cannot resolve.\n'
};

// src/protocol.ts
var MAX_CODE_BYTES = 64 * 1024;
var MAX_TEXT_BYTES = 64 * 1024;
var MAX_IMAGE_BYTES = 4 * 1024 * 1024;
var MAX_RESULT_BYTES = 6 * 1024 * 1024;
var DOCUMENTATION = contract_default.documentation;
var TOOLS = contract_default.tools;

// src/api.ts
function createCua(native2, write2, emitImage2, requestMeta = () => void 0) {
  let documented = false;
  let documentationRequest;
  function documentation() {
    if (!documented) {
      write2(DOCUMENTATION, "cua.core");
      documented = true;
      documentationRequest = requestMeta();
    }
  }
  async function inventory(op, options = {}) {
    documentation();
    const result = await native2(op);
    const value = result.items ?? result;
    if (options.emit !== false) write2(JSON.stringify(value), "cua.state");
    return value;
  }
  async function getApp(target) {
    documentation();
    if (!target || !Number.isSafeInteger(target.windowId) || target.windowId <= 0) throw new Error("linux getApp requires { windowId } from listApps() or listWindows().");
    const windows = (await native2("windows")).items;
    if (!windows.some((window) => window.id === target.windowId)) throw new Error(`Window ${target.windowId} is unavailable.`);
    const binding = await native2("bind", { windowId: target.windowId });
    let snapshotId = "";
    const base = () => ({ windowId: target.windowId, identity: binding.identity, snapshotId });
    const resolveTarget = (value) => Array.isArray(value) ? { coordinates: value } : { elementId: value };
    async function observe(image, text, options = {}) {
      const result = await native2("state", { ...base(), image, text });
      snapshotId = result.snapshotId;
      const bytes = result.image ? Buffer.from(result.image, "base64") : void 0;
      if (options.emit !== false) {
        if (text) write2(result.state, "cua.state");
        if (bytes) await emitImage2(bytes);
      }
      return bytes ? { state: result.state, screenshot: bytes } : { state: result.state };
    }
    const app = {
      getAXState: async (options) => (await observe(false, true, options)).state,
      getScreenshot: async (options) => (await observe(true, false, options)).screenshot,
      getAXStateAndScreenshot: (options) => observe(true, true, options),
      click: async (value, options = {}) => {
        if (options.durationMs !== void 0) {
          if (!Array.isArray(value)) throw new Error("Linux timed clicks require window-relative coordinates.");
          if (!Number.isSafeInteger(options.durationMs) || options.durationMs < 0) throw new Error("durationMs must be a non-negative safe integer.");
        }
        if (options.key !== void 0 && !Array.isArray(value)) throw new Error("Linux clicks with key require window-relative coordinates.");
        await native2("click", { ...base(), ...resolveTarget(value), ...options });
      },
      drag: async (from, to) => {
        await native2("drag", { ...base(), from, to });
      },
      scroll: async (value, direction, distance) => {
        if (typeof distance === "number") throw new Error("Linux scroll accepts { pixels }, not pages.");
        if (distance && (!Number.isFinite(distance.pixels) || distance.pixels <= 0)) throw new Error("pixels must be a positive finite number.");
        await native2("scroll", { ...base(), ...resolveTarget(value), direction, ...distance ? { pixels: distance.pixels } : {} });
      },
      selectText: async (..._args) => {
        throw new Error("selectText is unavailable on Linux.");
      },
      setValue: async (..._args) => {
        throw new Error("setValue is unavailable on Linux; use click, pressKey, and typeText.");
      },
      paste: async (text, options) => {
        if (options?.format !== void 0 && options.format !== "text") throw new Error("Linux paste supports only text format.");
        await native2("type_text", { ...base(), text });
      },
      pressKey: async (key, options) => {
        if (options?.durationMs !== void 0 && (!Number.isSafeInteger(options.durationMs) || options.durationMs < 0)) throw new Error("durationMs must be a non-negative safe integer.");
        await native2("press_key", { ...base(), key, ...options });
      },
      typeCharacters: async (text) => {
        const result = await native2("type_characters", { ...base(), text });
        return { charactersSent: result.charactersSent };
      },
      typeText: async (text, elementId) => {
        await native2("type_text", { ...base(), text, elementId });
      },
      performSecondaryAction: async (elementId, action) => {
        await native2("secondary", { ...base(), elementId, action });
      }
    };
    await app.getAXState();
    return app;
  }
  return {
    getState: (options) => inventory("inventory", options),
    listWindows: (options) => inventory("windows", options),
    listApps: (options) => inventory("apps", options),
    getApp,
    computer: {
      target: "linux",
      launch_app: async (input) => {
        await native2("launch_app", input);
      }
    },
    rewriteDocumentation: async () => {
      if (!documented) {
        documentation();
        return;
      }
      const meta = requestMeta();
      if (meta == null || meta !== documentationRequest) {
        write2(DOCUMENTATION, "cua.core");
        documentationRequest = meta;
      }
    }
  };
}

// src/worker.ts
var session = new inspector.Session();
session.connect();
var current;
var execution = new AsyncLocalStorage();
var requestId = 0;
var pending = /* @__PURE__ */ new Map();
function send(value) {
  if (process.connected) process.send?.(value);
}
function emit(content, name) {
  if (!current || execution.getStore() !== current.id) throw new Error("No active JavaScript execution");
  send({ type: "content", id: current.id, content, name });
}
async function native(op, args = {}) {
  if (!current || execution.getStore() !== current.id) throw new Error("CUA operation outside an active js call");
  const id = ++requestId;
  const promise = new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
  send({ type: "native", id: current.id, requestId: id, request: { op, args } });
  return promise;
}
var pendingConsoleNewline = false;
var write = (value, name) => {
  if (pendingConsoleNewline) {
    emit({ type: "text", text: "\n" });
    pendingConsoleNewline = false;
  }
  emit({ type: "text", text: typeof value === "string" ? value : inspect(value) }, name);
};
var consoleLine = (...values) => {
  write(format(...values));
  pendingConsoleNewline = true;
};
var emitImage = async (value) => {
  let mimeType;
  if (typeof value === "object" && value !== null && "bytes" in value) {
    const input = value;
    mimeType = input.mimeType;
    value = input.bytes;
  }
  if (typeof value === "string") {
    if (value.startsWith("file:")) value = await readFile(new URL(value));
    else {
      const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/]*={0,2})$/.exec(value);
      if (!match) throw new Error("emitImage expects a data URL, file URL, image bytes, or { bytes, mimeType }.");
      mimeType = match[1];
      value = Buffer.from(match[2], "base64");
    }
  }
  if (!(value instanceof Uint8Array)) throw new Error("emitImage expects a data URL, file URL, image bytes, or { bytes, mimeType }.");
  const data = Buffer.from(value);
  mimeType ??= data.subarray(0, 4).toString("hex") === "89504e47" ? "image/png" : data.subarray(0, 3).toString("hex") === "ffd8ff" ? "image/jpeg" : data.subarray(0, 4).toString() === "RIFF" && data.subarray(8, 12).toString() === "WEBP" ? "image/webp" : void 0;
  if (!mimeType || !["image/png", "image/jpeg", "image/webp"].includes(mimeType)) throw new Error("Unsupported image format.");
  emit({ type: "image", mimeType, data: data.toString("base64"), _meta: { "codex/imageDetail": "original" } });
};
var cua = createCua(native, write, emitImage, () => current?.context.request_meta);
Object.assign(globalThis, {
  cua,
  nodeRepl: Object.freeze({ write, emitImage, get requestMeta() {
    return current?.context.request_meta;
  } }),
  console: Object.freeze({ log: consoleLine, info: consoleLine, debug: consoleLine, error: consoleLine, warn: consoleLine, dir: (value) => consoleLine(inspect(value)) })
});
process.on("message", (message) => {
  if (message.type === "native_result") {
    const entry = pending.get(message.requestId);
    if (!entry) return;
    pending.delete(message.requestId);
    if (message.error) entry.reject(new Error(message.error));
    else entry.resolve(message.value);
    return;
  }
  if (message.type !== "execute" || current) return;
  current = message;
  pendingConsoleNewline = false;
  execution.run(message.id, () => session.post("Runtime.evaluate", {
    expression: message.code,
    replMode: true,
    awaitPromise: true,
    timeout: message.timeout,
    objectGroup: message.id
  }, (error, rawResponse) => {
    const response = rawResponse;
    const id = current?.id;
    let failure = error?.message;
    if (response?.exceptionDetails) {
      const description = response.exceptionDetails.exception?.description ?? response.exceptionDetails.text;
      failure = description.split("\n    at ")[0].replace(/^(?:Uncaught )?(?:\w*Error): /, "");
      const token = /^Unexpected token '(.*)'$/.exec(failure);
      if (response.exceptionDetails.exception?.className === "SyntaxError" && token) {
        const line = response.exceptionDetails.lineNumber + 1;
        const column = response.exceptionDetails.columnNumber;
        failure = `[${line}:${column}-${line}:${column + token[1].length}]: Unexpected token: '${token[1]}'`;
      }
    }
    if (pending.size && !failure) failure = "Await every CUA operation before js returns.";
    current = void 0;
    for (const entry of pending.values()) entry.reject(new Error("JavaScript execution ended"));
    pending.clear();
    session.post("Runtime.releaseObjectGroup", { objectGroup: message.id });
    session.post("Runtime.discardConsoleEntries");
    send({ type: "done", id, error: failure });
  }));
});
process.on("disconnect", () => process.exit(0));
